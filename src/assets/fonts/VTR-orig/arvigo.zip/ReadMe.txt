ARVIGO
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Eagle-eyed regulars to the Fontworks may recognize the word "Arvigo;" it's in the sample graphic for Hultog, one of my very first fonts. Like that one and a couple of others, the inspiration comes from my long-running FRP campaign (I've been developing the same setting now since my teenage years, so making references to it just feels natural). Arvigo is, as you might guess from his new font, a rather unpleasant character - a shifty, machiavellian underworld figure lacking ethics, sympathy and, as it happens, his nose.

Arvigo is a full-keyboard set with a few of the usual extras, based on hand-drawn samples I doodled at Whataburger last night over a diet Dr. Pepper. Arvigo himself would consider it pretty.

This font is copyright 2002 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0
